class StringMath
{
   public static void main (String [] args)
   {
      System.out.println("The difference between 12 and 10 is " + (12 - 10));
   }

}