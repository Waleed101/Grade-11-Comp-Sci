class Random100
{
   public static void main (String [] args)
   {
      int random = (int)(Math.random(-100,100)*100);
      System.out.println(random);
   }
}