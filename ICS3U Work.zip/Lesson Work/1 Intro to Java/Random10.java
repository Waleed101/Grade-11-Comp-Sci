class Random10
{
   public static void main (String [] args)
   {
      int random = (int)(Math.random(0,10)*100);
      System.out.println(random);
   }
}