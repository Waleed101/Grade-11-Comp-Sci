// This program is fairly simple, it types using System.out.println, Hello World!

class HelloWorld
{
   public static void main (String [] args)
   {
      System.out.println("Hello World");
   }
}