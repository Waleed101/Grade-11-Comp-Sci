class Math
{
   public static void main (String [] args)
   {
      System.out.println(8 + 10);
      
   }

}