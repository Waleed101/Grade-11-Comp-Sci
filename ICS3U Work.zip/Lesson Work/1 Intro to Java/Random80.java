class Random80
{
   public static void main (String [] args)
   {
      int random = (int)(Math.random(25,80)*100);
      System.out.println(random);
   }
}