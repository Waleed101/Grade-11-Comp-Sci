class PersonInfo 
{
   public static void main (String [] args)
   {
      String name = "Waleed";
      int age = 14;
      int year = 2001;
      System.out.println(name + " is born in " + year + ". He is " + age + " Years old" );
   } 
}