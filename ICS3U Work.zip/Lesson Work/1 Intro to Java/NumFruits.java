class NumFruits
{
   public static void main (String [] args)
   {
      int apples = 23, bananas = 45, plums = 3000;
      System.out.println("INVENTORY:");
      System.out.println("Apples:\t\t" + apples );
      System.out.println("Bananas:\t" + bananas );
      System.out.println("Plums:\t\t" + plums );
      
      
   }
}