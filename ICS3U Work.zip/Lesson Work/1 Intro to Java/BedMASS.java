//Question 3: Using the program from question 2, perform some experiments using addition, subtraction, multiplication, and additional brackets.  
class BedMASS
{
   public static void main (String [] args)
   {
      System.out.println("Simple Equation: " + (8 + 10));
      System.out.println("Complex Equation: " + (2 + 4 * 5));
   }
}