class Temperature
{
   public static void main (String [] args)
   {
      double cel = 34; //Celsius  
      double fah = cel * 9/5 + 32; //Fahrenheit
      System.out.println(cel + " Celsius in Fahrenheit is " + fah);
   }
}