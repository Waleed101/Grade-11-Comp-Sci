class Locations
{
   public static void main (String [] args)
   {
      String city = "Winnipeg";
      String country = "Canada";
      System.out.println(city + " is a city in " + country);
   }
}