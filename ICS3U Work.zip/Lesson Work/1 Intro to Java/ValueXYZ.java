class ValueXYZ
{
   public static void main (String [] args)
   {
      int x,y,z;
      x = 5;
      y = 8;
      z = y - x;
      x = x + 1;
      y = x - 10;
      z = x + y;
    }
}