import java.util.Scanner;

class AgeScanner
{
   
}