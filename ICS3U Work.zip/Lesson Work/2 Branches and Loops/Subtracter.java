class Subtracter
{
   public static void main (String [] args)
   {
      int i = 11;
      int num = 10;
      
      while (i > 0)
      {
         System.out.print(num + "\t");
         num--;
         i--;      
      }
      
   }
}