class TwoCounter
{
   public static void main (String [] args)
   {
      int i = 11;
      int num = 0;
      
      while (i > 0)
      {
         System.out.print(num + "\t");
         num+=2;
         i--;      
      }
      
   }
}