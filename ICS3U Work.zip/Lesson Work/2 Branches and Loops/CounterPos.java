class CounterNeg
{
   public static void main (String [] args)
   {
      for(int i = 20; i >= 0; i--)
      {
         System.out.println(i);
      } 
   }
}