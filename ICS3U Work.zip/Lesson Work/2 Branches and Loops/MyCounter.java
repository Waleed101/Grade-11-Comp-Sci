class MyCounter
{
   public static void main (String [] args)
   {
      int i = 11;
      int num = 5;
      
      while (i > 0)
      {
         System.out.println(num);
         num++;
         i--;      
      }
      
   }
}