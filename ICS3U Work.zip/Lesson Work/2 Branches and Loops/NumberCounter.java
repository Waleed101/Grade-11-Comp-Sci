import java.util.Scanner;

class NumberCounter
{
   public static void main(String [] args)
   {
      Scanner sc = new Scanner (System.in);
      int; 
   }
}