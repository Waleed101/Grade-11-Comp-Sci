class Inspirational
{
   public static void main (String [] args)
   {
      int i = (int)(Math.random() * 5);
      if (i == 0)
         System.out.println("You will do awful in life");
      if (i == 1)
         System.out.println("You will do moderatly awful in life");
      if (i == 2)
         System.out.println("You will do okay in life");
      if (i == 3)
         System.out.println("You will do moderatly great in life");
      if (i == 4)
         System.out.println("You will do great in life");
          
   }
}