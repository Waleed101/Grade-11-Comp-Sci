class SumCalculator
{
   static int calcSum(int numOne, int numTwo, int numThree) 
   {
    return numOne + numTwo + numThree;  
   }
   
   public static void main (String [] args)
   {
    System.out.println(calcSum(1,2,3));  
   }
   
}
