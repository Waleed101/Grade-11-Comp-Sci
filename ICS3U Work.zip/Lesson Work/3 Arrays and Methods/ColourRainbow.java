class ColourRainbow
{
   public static void main(String [] args)
   {
      String[] colors = {"Red" , "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"};
      for (int i = 0; i < 5; i++)
      {
         System.out.print(colors[i] + ", ");
      }
   }
}