import java.util.Scanner;

class StaticVariable
{
   static String[] names = new ;
   static void shortNames()
   {
   
   }
   
   static void longNames()
   {
   
   }
   
   public static void main(String[]args)
   {
   
   }
}