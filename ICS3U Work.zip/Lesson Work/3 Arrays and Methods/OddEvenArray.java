class OddEvenArray
{
   public static void main (String [] args)
   {
      int [] unsorted = {1, 23, 6, 8, 13, 15};
      int [] sorted;
      for (int i = 0; i < 6; i++)
      {
         if(unsorted[]
      }
   }
}