class PrintLondon
{

   static void printCity()
   {
      System.out.println("London is a city in Ontario.");
   }
   
   public static void main(String[] args)
   {
      printCity();
   }
}