//nested loop demo

import java.util.Scanner;

class NumberPatternUsingNestedForLoop2
{
   public static void main(String[] args)
   {
      //declarations
      Scanner inData = new Scanner(System.in);
      int numberOfLines = 1;
      
      while (numberOfLines != 0)
      {
         //input number of lines
         System.out.print("How many rows would you like? (Enter 0 to quit)");
         numberOfLines = inData.nextInt();
      
         //outputs pattern
         for(int i = 1; i <= numberOfLines; i++)
         {
            for(int j = 1; j <= i; j++)
            {
               System.out.print(j + " ");
            }
            System.out.print("\n");
         }
      }
      
      System.out.println("Bye, hope you enjoyed the patterns!");     
     
      
   }
}