//nested loop demo

import java.util.Scanner;

class NumberPatternUsingNestedForLoop
{
   public static void main(String[] args)
   {
      //declarations
      Scanner inData = new Scanner(System.in);
      int numberOfLines = 1;
      
      //input number of lines
      System.out.print("How many rows would you like?");
      numberOfLines = inData.nextInt();
      
      //outputs pattern
      for(int i = 1; i <= numberOfLines; i++)
      {
         for(int j = 1; j <= i; j++)
         {
            System.out.print(j + " ");
         }
         System.out.print("\n");
      }      
     
      
   }
}