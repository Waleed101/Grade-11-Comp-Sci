//for loop demo

import java.util.Scanner;
class ForLoopUsingVariables
{
   public static void main(String[] args)
   {
      //variables
      int firstNumber, lastNumber, increment;
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.print("Enter the first number: ");
      firstNumber = inData.nextInt();
      
      System.out.print("Enter the last number: ");
      lastNumber = inData.nextInt();
      
      System.out.print("Enter the increment: ");
      increment = inData.nextInt();
      
      
      //output loop
      for (int i = firstNumber; i <= lastNumber; i=i+increment)
      {
         System.out.println(i);
      }
      
      
   }
}