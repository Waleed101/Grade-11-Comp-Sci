//using a for loop add numbers

import java.util.Scanner;
class AddNumbersUsingForLoop
{
   public static void main(String[] args)
   {
      //declarations
      Scanner inData = new Scanner(System.in);
      int numberOfNumbers, sum = 0;
      
      //input
      System.out.print("How many numbers would you like to add? ");
      numberOfNumbers = inData.nextInt();
      
      //loop to read in numbers and compute sum
      for (int i = 1; i <= numberOfNumbers; i++)
      {
         System.out.print("Enter number " + i + " : ");
         sum = sum + inData.nextInt();
      }
      
      //output
      System.out.println("The sum of your numbers is " + sum + ".");
   }
}