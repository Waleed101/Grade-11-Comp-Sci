//switch demo using strings - might not work on the school computers depending on version of Java

import java.util.Scanner;

class SwitchDemoUsingStrings
{
   public static void main(String[] args)
   {
      //variables
      String yesOrNo = new String("");
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.print("Would you like some delicious Java?");
      yesOrNo = inData.nextLine();
      
      //switch block for output
      switch (yesOrNo.toLowerCase())
      {
         case "yes":
            System.out.println("Me too.");
            break;
            
         case "no":
            System.out.println("Great, more for me.");
            break;
            
         default:
            System.out.println("You should have typed \"yes\" or \"no\".");
            break;
      }
      
   }
}