//switch demo using some cases without break, also includes nested if
//program asks user for a year and a month, outputs number of days in that month

import java.util.Scanner;

class SwitchDemoDaysInMonth 
{
    public static void main(String[] args) 
    {
        //variables
        int month, year, numberOfDays = 0;
        
        Scanner inData = new Scanner(System.in);
        
        //input year
        System.out.print("Enter the year: ");
        year = inData.nextInt();
        
        //input month number
        System.out.print("Enter the month (1 - 12): ");
        month = inData.nextInt();
        
        //switch block to determine number of days
        switch (month) 
        {
            case 1:                    //thsee months all have 31 days
            case 3:                    //case statements could all be on one line, doesn't matter
            case 5: 
            case 7: 
            case 8: 
            case 10:
            case 12:
                numberOfDays = 31;
                break;
            case 4: 
            case 6:
            case 9: 
            case 11:
                numberOfDays = 30;
                break;
            case 2:
                if (((year % 4 == 0) && !(year % 100 == 0))|| (year % 400 == 0)) //leap year determination
                    numberOfDays = 29;                                           //a year is 365 days 5 hours 48 minutes 46 seconds
                else                                                             //so the correction is more complicated that every 4 years
                    numberOfDays = 28;
                break;
            default:
                System.out.println("That's not a month.");
                break;
        }
        
        //output message
        System.out.println("The number of days in month " 
            + month + " of " + year + " is "+ numberOfDays + ".");
    }
}