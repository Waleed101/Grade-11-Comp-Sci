//switch demo - user enters a number to choose food option, then orders quantity,
//program outputs price

import java.util.Scanner;
import java.text.DecimalFormat;

class SwitchDemoFoodOrder
{
   public static void main(String[] args)
   {
      //variables
      int optionNumber, quantity;
      double price = 0;
      String foodChoice = new String("");
      
      //scanner and formatting objects
      Scanner inData = new Scanner(System.in);
      DecimalFormat money = new DecimalFormat("$0.00");
      
      //prints menu options
      System.out.println("Choose from the following options:");
      System.out.println(" 1: hot dog     $2.50");
      System.out.println(" 2: hamburger   $3.75");
      System.out.println(" 3: tofu        $3.25");
      
      //input
      System.out.print("Enter an option from 1 to 3: ");
      optionNumber = inData.nextInt();
      
      //switch block to assign values based on user's choice
      switch (optionNumber)
      {
         case 1:
            foodChoice = "hot dog";
            price = 2.5;
            break;
         case 2:
            foodChoice = "hamburger";
            price = 3.75;
            break;
         case 3:
            foodChoice = "tofu";
            price = 3.25;
            break;
      }
      
      //input quantity of food item
      System.out.print("How many " + foodChoice + "s would you like?");
      quantity = inData.nextInt();
      
      //output and calculation
      System.out.println("The cost of " + quantity + " " + foodChoice + "s is " 
         + money.format(quantity * price) + ".");
      
      
   }
}