//demonstrates relational operators such as greater than, less than, equal to, etc

class DemonstratesRelationalOperators
{
   public static void main(String[] args)
   {
      //greater than
      System.out.println("10 is greater than 9 is " + (10 > 9));
      System.out.println("9 is greater than 10 is " + (9 > 10));
      System.out.println();
      
      //less than
      System.out.println("10 is less than 9 is " + (10 < 9));
      System.out.println("9 is less than 10 is " + (9 < 10));
      System.out.println();
      
      //greater than or equal to, less than or equal to
      System.out.println("10 is less than or equal to 10 is " + (10 <= 10));
      System.out.println("10 is greater than or equal to 9 is " + (10 >= 9));
      System.out.println();
      
      //equal to
      System.out.println("10 is equal to 10 is " + (10 == 10));
      System.out.println("9 is less than 10 is " + (9 == 10));
      System.out.println();
      
      //not equal to
      System.out.println("10 is not equal to 9 is " + (10 != 9));
      System.out.println("10 is not equal to 10 is " + (10 != 10));
      

      
   }
}