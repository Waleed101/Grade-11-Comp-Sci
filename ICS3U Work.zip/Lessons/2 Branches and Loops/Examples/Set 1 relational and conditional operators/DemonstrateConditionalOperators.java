//demonstrates conditional operators AND and OR

class DemonstrateConditionalOperators
{
   public static void main(String[] args)
   {
      //the AND operator (Java syntax: &&)
      System.out.println(true && true);                  //true
      System.out.println(true && false);                 //false
      System.out.println(false && true);                 //false
      System.out.println(false && false);                //false
      System.out.println();
      
      //the OR operator(Java syntax: ||  
      System.out.println(true || true);                  //true
      System.out.println(true || false);                 //true
      System.out.println(false || true);                 //true
      System.out.println(false || false);                //false
      System.out.println();
      
      //boolean type variables
      boolean A = true;                                  //declares boolean primitive type variables,
      boolean B = false;                                 //and initializes them with values.
                                                         //boolean variables can only store true or false
      
      System.out.println("The value of A is " + A);      //prints the value of A, which is true
      System.out.println("The value of B is " + B);      //prints the value of B, which is false
      System.out.println();
      
      System.out.println("The value of A AND B is " + (A && B));  //false
      System.out.println("The value of A OR B is " + (A || B));   //true
      System.out.println();
      
      
      //other things we can do
      boolean C;                          //declares another boolean variable
      
      C = A || B;                         //C is assigned the value of A OR B, which is true since A is true
      System.out.println(C);
      System.out.println();
      
      
      C = (A || B) && A;                  //now C is assigned the value of ((A OR B) AND A), which is true
      System.out.println(C);              //because A OR B is true and A is true
      System.out.println();
      
      C = (A || B) && (A && B);           //now C is assigned the value of ((A OR B) and (A AND B)) which is
      System.out.println(C);              //false since A AND B is false
      System.out.println();
      

      
   }  
}