//example of if/else if/else structure

import java.util.Scanner;

class PassFail2
{
   public static void main(String[] args)
   {
      //variable
      int grade;
      
      //Scanner object
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.print("Enter your grade :");
      grade = inData.nextInt();
      
      //test if pass or fail and output message
      if (grade >= 50 && grade <= 100)  
         System.out.println("You passed!");
      else if (grade >= 0 && grade < 50)
         System.out.println("You failed...");
      else
         System.out.println("Um... that's not a real mark.");
   }
}