//example of if/else structure
//program prompts for a grade and outputs pass/fail message

import java.util.Scanner;

class PassFail
{
   public static void main(String[] args)
   {
      //variable
      int grade;
      
      //Scanner object
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.print("Enter your grade: ");
      grade = inData.nextInt();
      
      //test if pass or fail and output message
      if (grade >= 50)
      
         System.out.println("You passed!");
         
      else
      
         System.out.println("You failed...");
   }
}