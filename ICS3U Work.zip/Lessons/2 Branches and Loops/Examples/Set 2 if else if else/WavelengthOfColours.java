//demonstrates multiple conditions for if/else if/else structures,
//OR conditional operator, and comparing strings

//program asks user to pick a colour of the rainbow then outputs
//wavelength message

import java.util.Scanner;

class WavelengthOfColours
{
   public static void main(String[] args)
   {
       
      //string to store user's input
      String colour;
      
      //input
      Scanner inData = new Scanner(System.in);
      System.out.println("Enter a colour of the rainbow:");
      colour = inData.nextLine();
      
      //output
      if (colour.equals("red") || colour.equals("orange"))
      
         System.out.println("You picked a long wavelength colour.");
     
      else if (colour.equals("yellow") || colour.equals("green"))
      
         System.out.println("You picked a medium wavelength colour.");
         
      else if (colour.equals("blue") || colour.equals("indigo") || colour.equals("violet"))
      
         System.out.println("You picked a short wavelength colour.");
         
      else
      {
         System.out.println("I'm sorry, I don't recognize that colour.");
         System.out.println("You blew it.");
      }
      
   }
   
}