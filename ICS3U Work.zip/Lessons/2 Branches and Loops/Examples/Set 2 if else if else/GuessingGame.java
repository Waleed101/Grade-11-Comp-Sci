//guessing game to demonstrate random numbers and if/then structures

import java.util.Scanner;

class GuessingGame
{
   public static void main(String[] args)
   {
      //variables
      int randnum = (int)(Math.random()*3) + 1;
      int guess;
      
      //Scanner object
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.println("Enter your guess from 1 to 3");
      guess = inData.nextInt();
      
      //test if correct and output result
      if (guess == randnum)
      
         System.out.println("You win!");
         
      else
      {
         System.out.println("You lose...");
         System.out.println("The correct answer was " + randnum);
      }
    }
}
