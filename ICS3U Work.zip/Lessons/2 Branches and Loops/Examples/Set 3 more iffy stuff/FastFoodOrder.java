//takes user's fast food order
//demonstrates nested if statements

import java.util.Scanner;

class FastFoodOrder
{
   public static void main(String[] args)
   {
      //declarations
      Scanner inData = new Scanner(System.in);
      String answer;
      
      //input
      System.out.print("Would you like fries with that? ");
      answer = inData.nextLine();
      
      
      //main if block
      if (answer.equals("yes"))
      {
         System.out.print("Would you like ketchup for your fries? ");
         answer = inData.nextLine();
         
         //nested if block - only happens if user says yes to fries
         if (answer.equals("yes"))
            System.out.println("Great.  Our fries go great with ketchup.");
         else if (answer.equals("no"))
            System.out.println("Good choice.  Our ketchup isn't good.");
         else
            System.out.println("Um... I'll go get the manager....");
      }
      else if (answer.equals("no"))
         System.out.println("Good choice.  Our fries aren't good.");
      else
         System.out.println("Um.... I'll go get the manager....");
      }
}