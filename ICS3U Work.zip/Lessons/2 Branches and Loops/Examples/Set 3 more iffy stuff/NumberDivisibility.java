//this program tells if a number is divisible by 2, 3, and/or 5
//using multiple if statements

import java.util.Scanner;

class NumberDivisibility
{
   public static void main(String[] args)
   {
      //declarations
      Scanner inData = new Scanner(System.in);
      int number;
      
      //input
      System.out.print("Enter a number: ");
      number = inData.nextInt();
      
      //testing divisibility and output
      
      //divisibility by 2
      if (number%2 == 0)  //true if number is divisible by 2
         System.out.println("Your number is divisible by 2.");
      else
         System.out.println("Your number isn't divisible by 2.");
      
      //new if statement to test for divisibility by 3   
      if (number%3 == 0)  
         System.out.println("Your number is divisible by 3.");
      else
         System.out.println("Your number isn't divisible by 3.");
      
      //another new if statement for divisibility by 5   
      if (number%5 == 0)  
         System.out.println("Your number is divisible by 5.");
      else
         System.out.println("Your number isn't divisible by 5.");
      
      
   }
}