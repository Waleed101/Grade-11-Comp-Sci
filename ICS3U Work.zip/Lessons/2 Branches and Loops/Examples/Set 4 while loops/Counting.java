//while loop demo

class Counting
{
   public static void main(String[] args)
   {
      int number = 0;
      
      while (number <= 10)                   //this loop executes WHILE the value of number
      {                                      //is less than or equal to 10
         System.out.println(number);
         number++;                           //adds 1 to the value of number
      }                                      //this could also have been accomplished with
   }                                         //number = number + 1;

}