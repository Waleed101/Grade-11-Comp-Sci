//while loop demo
import java.util.Scanner;

class SquareNumbersUntilUserQuits
{
   public static void main(String[] args)
   {
      //declarations
      int number;                                     //stores the number to be squared                                     
      String yesOrNo;                                 //stores y or n to continue or not
      boolean keepUsing = true;                       //true until user wants to quit
      Scanner inDataNumber = new Scanner(System.in);  //scanner for number to be squared
      Scanner inDataText = new Scanner(System.in);    //scanner for inputting y or n choice
      
      //loop
      while (keepUsing)       
      {
         //squaring user's number
         System.out.print("Enter a number to be squared: ");
         number = inDataNumber.nextInt();
         System.out.println(number + " squared equal " + Math.pow(number,2));
         
         //asking if user wants to keep using program
         System.out.print("Would you like to square another number? (y/n): ");
         yesOrNo = inDataText.nextLine();
         System.out.println(); 
         
         //change keepUsing to false if user wants to quit
         if (yesOrNo.equals("n"))
            keepUsing = false; 
      }
      
      //end of program message
      System.out.println("Thanks for using this program.");
   }
}