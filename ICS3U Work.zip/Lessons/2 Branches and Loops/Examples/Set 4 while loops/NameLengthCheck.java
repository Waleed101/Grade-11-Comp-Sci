//another while loop demo

import java.util.Scanner;

class NameLengthCheck
{
   public static void main(String[] args)
   {
      //declarations
      String name;      
      Scanner inData = new Scanner(System.in);
      
      //user enters name
      System.out.print("Enter your name :");
      name = inData.nextLine();      
      
      //loop to force user to enter a name with at least 2 characters
      while (name.length() < 2)
      {
         System.out.println("Your name must be at least 2 characters!");
         System.out.print("Please try again: ");
         name = inData.nextLine();      
      }
      
      //end of program message
      System.out.println("Thanks for entering a valid name, " + name + "!" );
      
   }
}