//this program finds the total number of fruits

class FruityMath
{
   public static void main(String[] args)
   {
      //variable declarations
      int numberOfApples;
      int numberOfOranges;
      int totalFruits;
      
      //initializing variables (giving them values)
      numberOfApples = 23;
      numberOfOranges = 32;
      
      //calculation
      totalFruits = numberOfApples + numberOfOranges;
      
      //output
      System.out.println("Apples: " + numberOfApples);
      System.out.println("Oranges: " + numberOfOranges);
      System.out.println("Total fruit: " + totalFruits);
   }
}