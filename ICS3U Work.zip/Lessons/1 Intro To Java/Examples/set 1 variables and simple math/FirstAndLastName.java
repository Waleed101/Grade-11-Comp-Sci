//demonstrates String variables
class FirstAndLastName
{
   public static void main(String[] args)
   {
      //variable declarations
      String firstName;
      String lastName;
      
      //initializing variables
      firstName = "Doug";
      lastName = "Jines";
      
      //output
      System.out.println("The first name is " + firstName + " and the last name is " + lastName);
      
      
   }
}