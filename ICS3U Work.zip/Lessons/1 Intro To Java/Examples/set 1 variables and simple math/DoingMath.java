class DoingMath
{
   public static void main(String[] args)
   {
      System.out.println(5 + 6);
      System.out.println("The product of 30 and 43 is " + (30*40));
   }
}