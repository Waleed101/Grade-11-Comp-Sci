// this is just an example program for learning purposes

/* this is what you use if you 
want to 
write multiple lines 
of comments*/

public class HelloICS3U
{
   public static void main(String[] args)
   {
      System.out.println("Hello Steve!!!!!!");
      System.out.println("This course will be awesome!");      
   }
}