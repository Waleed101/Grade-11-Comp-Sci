//demonstrating Scanner class for user input

import java.util.Scanner;                       //imports package containing Scanner class
                                                //which is needed for user-inputted data

class HelloName                                 //header for the class HelloName
{
   public static void main(String[] args)       //main method header
   {
      String name;                              //declares s String object called 'name'
                                                //which will store the user's name
      
      Scanner inData;                           //creates a REFERENCE name for a Scanner input object
      
      inData = new Scanner(System.in);          //CONSTRUCTS the input object with a METHOD for being filled (System.in)
                                                //now that it has a reference variable and has been
                                                //constructed, it now exists.  Its methods can now be used.
                                                      
      System.out.println("Enter your name:");   //prompts user for input
      
      name = inData.nextLine();                 //reads in name using the Scanner object's nextLine() method
                                                //which basically just reads in the next line
      
      
      System.out.println("Hello " + name + "!");   //outputs Hello message                                        
   }
}