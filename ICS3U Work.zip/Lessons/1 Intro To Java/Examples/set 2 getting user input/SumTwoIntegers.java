//example which finds the sum of two user-inputted integers

import java.util.Scanner;

class SumTwoIntegers
{
   public static void main(String[] args)
   {
      //variable declarations
      int firstNumber, secondNumber, sum;          //more than one variable can be declared per line
                                                   //if they are the same type                    
      
      //user input
      Scanner inData = new Scanner(System.in);     //Scanner object given reference name and
                                                   //constructed in one statement
      
      System.out.println("Enter a number:");       //prompts for first number
      firstNumber = inData.nextInt();              //reads in first number - notice it must 
                                                   //be nextInt() instead of nextLine()
      
      System.out.println("Enter another number:"); //prompts for second number
      secondNumber = inData.nextInt();             //reads in second number
      
      //calculation
      sum = firstNumber + secondNumber;            //calculates the sum       
      
      //output
      System.out.println("The sum is "+ sum);       //prints the result
   }
}