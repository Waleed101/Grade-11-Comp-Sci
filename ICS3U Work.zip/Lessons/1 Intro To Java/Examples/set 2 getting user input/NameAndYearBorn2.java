//demonstrates using Scanner objects for strings and integers
//in the same program THAT ACTUALLY WORKS

//user inputs name and age, program outputs year born

import java.util.Scanner;                       //imports Scanner class

class NameAndYearBorn2
{
   public static void main(String[] args)
   {
      //variable declaration:
      String name;                              //user's name
      int age, year;                            //user's age and year born
      
      //user input
      Scanner inData1 = new Scanner(System.in); //scanner object for integers
      Scanner inData2 = new Scanner(System.in); //scanner object for strings
      
      System.out.println("Enter your age:");    //prompts user for age
      age = inData1.nextInt();                  //reads in age
      
      System.out.println("Enter your Name:");   //prompts user for name
      name = inData2.nextLine();                //reads in name
      
      //calculates year born       
      year = 2015 - age;
      
      //outputs year born
      System.out.println(name + ", you were born in "+ year);
   }
}