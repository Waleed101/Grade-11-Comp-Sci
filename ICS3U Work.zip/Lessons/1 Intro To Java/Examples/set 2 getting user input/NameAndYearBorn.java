/*demonstrates using Scanner objects for strings and integers
in the same program IN A WAY THAT DOESN'T WORK!!!!

User inputs name and age, program IS SUPPOSED TO output year born*/

import java.util.Scanner;

class NameAndYearBorn
{
   public static void main(String[] args)
   {
      String name;
      int age;
      int year;
      
      Scanner inData = new Scanner(System.in);
      
      System.out.println("Enter your age:");
      age = inData.nextInt();
      
      System.out.println("Enter your Name:");
      name = inData.nextLine();
      
      year = 2015 - age;
      System.out.println(name + ", you were born in "+ year);
   }
}


/*using nextLine() after using nextInt() for the same scanner object doesn't work
SO: create TWO scanner objects, one for reading in strings, and one for reading
in*/