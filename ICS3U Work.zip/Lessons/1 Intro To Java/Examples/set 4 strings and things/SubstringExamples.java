//demonstration of substring(int beginIndex) and substring(int beginIndex, int endIndex) methods

class SubstringExamples
{
   public static void main(String[] args)
   {
      String name = new String("Rod Torfulson's Armada featuring Herman Menderchuck");
      
      //using one argument - this is the starting location
      System.out.println(name.substring(1));   //prints from index 1 (inclusive) to end of string
      System.out.println();
      
      System.out.println(name.substring(23));   //prints from index 23 inclusive to end of string
      System.out.println();
      
      
      //using two arguments - these are the starting and ending locations
      System.out.println(name.substring(0, 2));  //prints from index 0 inclusive to index 2 exclusive
      System.out.println();

      System.out.println(name.substring(0, 3));
      System.out.println();
      
      
      System.out.println(name.substring(23, 38));
      System.out.println();

      
   }
}