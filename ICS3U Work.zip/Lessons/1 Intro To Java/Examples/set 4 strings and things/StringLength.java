//demonstration of length() method and trim() method

class StringLength
{
   public static void main(String[] args)
   {
      //*********************DEMO 1******************************
      
      //here is another way to declare and construct a String object
      String city = new String("Toronto");
      
      //this is an integer variable which stores the length of the city String
      int numberOfLetters = city.length();      //this line "calls" the length method of the String class
      
      //output for demo purposes
      System.out.println(city + " has " + numberOfLetters + " letters in its name.\n");
      
      
      
      //*********************DEMO 2******************************
      String province = new String("      Ontario       ");  //all the spaces are known as 'white space'
      
      numberOfLetters = province.length();
      
      System.out.println(province + " has " + numberOfLetters + " letters in its name.\n");
      
      
      //trimming off the white space from the beginning and end of the String
      province = province.trim();
      
      //finding the length of the new trimmed String
      numberOfLetters = province.length();
      
      //output
      System.out.println(province + " has " + numberOfLetters + " letters in its name.");
   }
}