//demonstrates the use of the 'escape character' \

class FormatStringsExamples
{
   public static void main(String[] args)
   {
      //starting a new line with \n
      System.out.println("This will be \nuseful \nfor Haikus \nalthough this isn't a Haiku. \nDarn.\n\n");
      
      //tabbing using \t
      System.out.println("Using tabs \tis handy \tfor making \tcolumns\n\n");
      
      //what if you REALLY want a backslash??? Use \\
      System.out.println("See, you can still print a backslash if you really want: \\");
      
   }
}