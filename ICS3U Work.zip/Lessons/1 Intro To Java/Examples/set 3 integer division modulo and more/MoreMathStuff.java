//this demonstrates powers, roots, rounding, absolute value, etc

class MoreMathStuff
{
   public static void main(String[] args)
   {
      /****************
      *powers examples*
      ****************/
      System.out.println("POWERS:");
      System.out.println("   Math.pow(2,3) = " + Math.pow(2,3));
      System.out.println("   Math.pow(-2,3) = " + Math.pow(-2,3));
      System.out.println("   Math.pow(2,-3) = " + Math.pow(2,-3));
      System.out.println();
      
      /*********************
      *square root examples*
      *********************/
      System.out.println("SQUARE ROOTS:");
      System.out.println("   Math.sqrt(16) = " + Math.sqrt(16));
      System.out.println("   Math.sqrt(27) = " + Math.sqrt(27));
      System.out.println();
      
      /******************
      *rounding examples*
      ******************/
      System.out.println("ROUNDING:");
      System.out.println("   Math.round(1.6584) = " + Math.round(1.6584));
      System.out.println("   Math.round(27.3432) = " + Math.round(27.3432));
      System.out.println("   Math.round(1.5) = " + Math.round(1.5));
      System.out.println();
      
      /************************
      *absolute value examples*
      ************************/
      System.out.println("ABSOLUTE VALUE:");
      System.out.println("   Math.abs(-8) = " + Math.abs(-8));
      System.out.println("   Math.abs(2.54) = " + Math.abs(2.54));
      System.out.println();
      
      /**********
      *constants*
      **********/
      System.out.println("CONSTANTS:");
      System.out.println("   Math.PI = "+ Math.PI);
      System.out.println("   Math.E = "+ Math.E);
      System.out.println();
      
      /*******************************************
      *random numbers (pseudorandom in actuality)*
      *******************************************/
      System.out.println("RANDOM NUMBER FROM 0 to 1 as a double primitive type:");
      System.out.println(Math.random());
      System.out.println();
      
      
      /**********************************************************
      *other stuff you can google - there are MANY math methods!*
      **********************************************************/
      
      System.out.println("Samples of the many others:");
      System.out.println("   Math.sin(0.5) = " + Math.sin(0.5));     //argument is in radians not degrees
      System.out.println("   Math.cbrt(1000) = " + Math.cbrt(1000)); //cube root
   }
}

//don't forget all the literals in these examples can be variables in your code