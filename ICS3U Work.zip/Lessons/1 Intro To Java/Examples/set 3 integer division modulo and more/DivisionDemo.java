//this demonstrates integer division and floating point division

class DivisionDemo
{
   public static void main(String[] args)
   {
      /**************************
      *integer division examples*
      ***************************/
      System.out.println("INTEGER DIVISION:");
      System.out.println("     1/2 = " + 1/2);                 //how many 2's fit into 1? none!
      System.out.println("     8/3 = " + 8/3);                 //how many 3's fit into 8? 2
      System.out.println("     1/2 + 1/2 = " + (1/2 + 1/2));   //division happens first (BEDMAS), so this becomes 0 + 0
      System.out.println();
      
      /*********************************
      *floating point division examples*
      **********************************/
      System.out.println("FLOATING POINT DIVISION:");                   
      System.out.println("     1.0/2 = " + 1.0/2);                   //if either (or both) operand is a decimal number,
      System.out.println("     1/2.0 = " + 1/2.0);                   //floating point division is performed
      System.out.println("     1.0/2.0 = " + 1.0/2.0);        
      System.out.println("     8f/3 = " + 8f/3);                     //the 'f' makes the '8' a float
      System.out.println("     1.0/2 + 1/2.0 = " + (1/2.0 + 1/2.0));
      System.out.println("     1d/2 + 1/2 = " + (1d/2 + 1/2));       //the 'd' makes the '1' a double
                                                                     //this becomes 0.5 + 0 since the second term
                                                                     //is still an integer division

      
   }
}