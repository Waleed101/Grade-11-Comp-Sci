//this demonstrates the modulo operation

class ModuloDemo
{
   public static void main(String[] args)
   {
      /*************************
      *modulo operator examples*
      **************************/
      System.out.println("MODULO EXAMPLES:");
      System.out.println("     13%5 = " + 13%5);      //13 mod 5 = 3 because 5 goes into 13 twice with a remainder of 3
      System.out.println("     20%4 = " + 20%4);      //20 mod 4 = 0 since 4 divides 20 evenly
      System.out.println("     6%8 = " + 6%8);        //6 mod 8 = 6 since 8 is larger than 6 (no 8's fit into 6, so the remainder is 6
   }
}

//note: the modulo operator is generally not used on floating point data