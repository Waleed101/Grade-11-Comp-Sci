class MakingRandomNumbers
{
   public static void main(String[] args)
   {
      //creates a pseudorandom double from 0 to 1
      double x = Math.random();
      
      System.out.println("original random double: \t\t" + x);
      
      //multiplying by 10 makes the number from 0 to 10
      System.out.println("times 10: \t\t\t\t" + x * 10);
      
      //putting (int) in front drops the decimal part, 'type casting' it into an integer
      System.out.println("putting (int) in front: \t\t" + (int)(x * 10));  //this will give an integer from 0 to 9
      
      //to make a random int from 0 to 10, you have to multiply by 11 since (int) is the same as rounding DOWN every time
      System.out.println("multiplying by 11 instead of 10: \t" + (int)(x * 11));
      
      //to make a random int from 5 to 15, add 5 afterwards
      System.out.println("random int from 5 to 15: \t\t" + ((int)(x * 11) + 5));
      
      //in general: (int)(Math.random() * (max - min + 1)) + min
   }
}