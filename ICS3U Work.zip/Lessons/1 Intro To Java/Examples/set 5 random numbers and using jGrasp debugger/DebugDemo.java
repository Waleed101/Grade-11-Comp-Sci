class DebugDemo
{
   public static void main (String[] args)
   {
      int x, y, sum;
      x = 5;
      y = 10;
      sum = x + y;
      
      x = 12;
      y = 25;
      
      System.out.println("The sum is " + sum);
   }
}

/*Imagine you were expecting the number 37 to be outputted at the end of the program,
but instead you saw 15.  To see what's going on, put a STOP in the margin at the x = 5; line,
then run the program in debug mode by clicking the ladybug icon.  On the left, you can
see what happens to each variable line by line by clicking the down icon.*/
