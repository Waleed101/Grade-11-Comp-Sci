import java.util.Scanner;

class MakingRandomNumbers2
{
   public static void main (String[] args)
   {
      //variable declarations
      int max, min, random;
      
      //scanner object for user input
      Scanner inData = new Scanner(System.in);
      
      //input
      System.out.print("Enter the min: ");
      min = inData.nextInt();
      System.out.print("Enter the max: ");
      max = inData.nextInt();
      
      //output (infinite loop - don't do this!!)
      while (true)
      {
         random = (int)(Math.random()*(max - min + 1))+ min;      //calculates random number
         System.out.println(random);                              //prints number to screen
      }
   }
}